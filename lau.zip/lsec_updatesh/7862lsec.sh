#!/system/bin/sh
rm -rf /data/dalvik-cache/profiles/190001022_com.android.launcher22
rm -rf /data/data/190001022_com.android.launcher22
rm -rf /data/dalvik-cache/arm64/*190001022_com.android.launcher22*
cp -r /storage/sdcard1/launcher/* /oem/app
chown -R 0.0 /oem/app/190001022_com.android.launcher22
chmod 755 /oem/app/190001022_com.android.launcher22
chmod 644 /oem/app/190001022_com.android.launcher22/190001022_com.android.launcher22.apk